#include "fuzzylite/FuzzyLogicController.h"
#include "fuzzylite/FuzzyLite.h"

namespace fl {

    class FuzzyLogicController {
    public:
        static void FuzzyLogicOne();
        static void FuzzyLogicTwo();
   //     static void main(int args, char** argv);
    };
}




